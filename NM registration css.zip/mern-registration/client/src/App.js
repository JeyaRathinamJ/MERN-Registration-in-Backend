import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import RegisterForm from "./RegisterForm"; // Import the RegisterForm component
import SignInForm from "./SignInForm";

const App = () => {
  return (
    <div className=" vh-100 bg-dark">
      <h1 className="text-center text-light py-4 ">MERN Registration</h1>
      <Router>
        <nav className="navbar d-flex justify-content-center navbar-expand-lg navbar-dark bg-dark">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/" className="nav-link" activeClassName="active-link">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/register"
                className="nav-link"
                activeClassName="active-link"
              >
                Register
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/signin"
                className="nav-link"
                activeClassName="active-link"
              >
                Sign In
              </Link>
            </li>
          </ul>
        </nav>

        <Routes>
          <Route
            path="/"
            element={
              <h2 className="text-light text-center mt-5 pt-4">
                Welcome to the Landing Page
              </h2>
            }
          />
          <Route path="/register" element={<RegisterForm />} />
          <Route path="/signin" element={<SignInForm />} />
        </Routes>
      </Router>
    </div>
  );
};

export default App;
