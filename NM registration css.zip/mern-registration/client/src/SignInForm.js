import React, { useState } from "react";

const SignInForm = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSignIn = () => {
    // Implement the sign-in logic here (e.g., authenticate with the server)
    // For this example, we'll just show an alert indicating a successful login.
    alert("Sign In successful!");
  };

  return (
    <div className="conatainer w-25 bg-light cont">
      <h2 className="text-center mb-3">Sign In</h2>
      <form>
        <div class="mb-3">
          <label for="Username" class="form-label">
            Username
          </label>
          <input
            type="text"
            placeholder="Username"
            class="form-control"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">
            Password
          </label>
          <input
            type="password"
            placeholder="Password"
            class="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="button" onClick={handleSignIn} class="btn btn-primary">
          Submit
        </button>
      </form>
    </div>
  );
};

export default SignInForm;
