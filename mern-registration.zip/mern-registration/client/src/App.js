import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import RegisterForm from './RegisterForm'; // Import the RegisterForm component
import SignInForm from './SignInForm';

const App = () => {
  return (
    <div>
      <h1>MERN Registration</h1>
      <Router>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/register">Register</Link>
            </li>
            <li>
              <Link to="/signin">Sign In</Link>
            </li>
          </ul>
        </nav>
        <Routes>
          <Route path="/" element={<h2>Welcome to the Landing Page</h2>} />
          <Route path="/register" element={<RegisterForm />} />
          <Route path="/signin" element={<SignInForm />} />
        </Routes>
      </Router>
    </div>
  );
};

export default App;
